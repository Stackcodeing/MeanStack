var msg = "My first node js program";
console.log(msg);